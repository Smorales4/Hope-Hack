var express = require('express')
var bodyParser = require('body-parser')

var db = require('./database')

const app = express();
const port = 5507;

app.use(bodyParser.urlencoded({ extended : true}));

app.get('/', (req, res) => {
    db.query(`SELECT * FROM Contact Log`, (error, results) => {
        res.json(results);
    });
}) 

app.post('/submit', (req, res) => {
    db.query(
        `INSERT INTO ContactLog (fullName, email, subject, message) VALUES ('${req.body.name}', '${req.body.email}', '${req.body.subject}', '${req.body.message}')`,
        (error, results) => {
            if(error) res.json(error);
            res.status('OK');
        }
    );
})

app.listen(port, () => {
    console.log(`App listening on port ${port}`);
});

module.exports = app;
